`timescale 1ns / 1ps

module tb_image_conv_top;

    localparam DATA_WIDTH  = 8;
    localparam COEFF_WIDTH = 8;
    localparam IMG_W       = 8;
    localparam IMG_H       = 8;
    localparam CLK_PERIOD  = 10; // 100 MHz target clock

    reg                          clk;
    reg                          rst_n;
    reg                          in_valid;
    reg  [DATA_WIDTH-1:0]        in_pixel;

    reg  signed [COEFF_WIDTH-1:0] k11, k12, k13;
    reg  signed [COEFF_WIDTH-1:0] k21, k22, k23;
    reg  signed [COEFF_WIDTH-1:0] k31, k32, k33;

    wire                         out_valid;
    wire [DATA_WIDTH-1:0]        out_pixel;

    // DUT Instance
    image_conv_top dut (
        .clk(clk),
        .rst_n(rst_n),
        .in_valid(in_valid),
        .in_pixel(in_pixel),
        .k11(k11), .k12(k12), .k13(k13),
        .k21(k21), .k22(k22), .k23(k23),
        .k31(k31), .k32(k32), .k33(k33),
        .out_valid(out_valid),
        .out_pixel(out_pixel)
    );

    // 100 MHz Clock Generator
    always #(CLK_PERIOD/2) clk = ~clk;

    // Verification Memory & Counters
    reg [7:0] current_frame [0:IMG_H-1][0:IMG_W-1];
    integer total_tests_passed;
    integer total_tests_failed;
    integer current_suite_passed;
    integer current_suite_failed;

    // Golden Reference Convolution & Saturation Function
    function [7:0] compute_golden;
        input integer r_center;
        input integer c_center;
        integer sum;
        begin
            sum = ($signed({1'b0, current_frame[r_center-1][c_center-1]}) * k11) +
                  ($signed({1'b0, current_frame[r_center-1][c_center  ]}) * k12) +
                  ($signed({1'b0, current_frame[r_center-1][c_center+1]}) * k13) +
                  ($signed({1'b0, current_frame[r_center  ][c_center-1]}) * k21) +
                  ($signed({1'b0, current_frame[r_center  ][c_center  ]}) * k22) +
                  ($signed({1'b0, current_frame[r_center  ][c_center+1]}) * k23) +
                  ($signed({1'b0, current_frame[r_center+1][c_center-1]}) * k31) +
                  ($signed({1'b0, current_frame[r_center+1][c_center  ]}) * k32) +
                  ($signed({1'b0, current_frame[r_center+1][c_center+1]}) * k33);

            if (sum < 0)
                compute_golden = 8'd0;
            else if (sum > 255)
                compute_golden = 8'd255;
            else
                compute_golden = sum[7:0];
        end
    endfunction

    // Task: Stream Single Frame
    task send_frame;
        integer r_idx, c_idx;
        begin
            for (r_idx = 0; r_idx < IMG_H; r_idx = r_idx + 1) begin
                for (c_idx = 0; c_idx < IMG_W; c_idx = c_idx + 1) begin
                    @(posedge clk);
                    #0.1;
                    in_valid <= 1'b1;
                    in_pixel <= current_frame[r_idx][c_idx];
                end
            end
            @(posedge clk);
            #0.1;
            in_valid <= 1'b0;
            in_pixel <= 8'd0;
        end
    endtask

    integer r_init, c_init;
    reg [31:0] rand_seed;

    // Main Stimulus Sequence
    initial begin
        clk                 = 0;
        rst_n               = 0;
        in_valid            = 0;
        in_pixel            = 0;
        total_tests_passed  = 0;
        total_tests_failed  = 0;
        rand_seed           = 32'hDEADBEEF;

        #(CLK_PERIOD * 10);
        @(posedge clk);
        #0.1;
        rst_n = 1;
        #(CLK_PERIOD * 5);

        // =====================================================================
        // TEST SUITE 1: Full Dynamic Range Random Stream
        // =====================================================================
        $display("\n========================================================");
        $display("[RUNNING] Test Suite 1: Full-Range Pseudo-Random Grayscale Stream");
        $display("========================================================");
        current_suite_passed = 0;
        current_suite_failed = 0;

        k11 = -8'sd3; k12 =  8'sd1; k13 =  8'sd2;
        k21 = -8'sd1; k22 =  8'sd4; k23 = -8'sd2;
        k31 =  8'sd0; k32 = -8'sd5; k33 =  8'sd1;

        for (r_init = 0; r_init < IMG_H; r_init = r_init + 1) begin
            for (c_init = 0; c_init < IMG_W; c_init = c_init + 1) begin
                current_frame[r_init][c_init] = $random(rand_seed) % 256;
            end
        end

        send_frame;
        #(CLK_PERIOD * 35);
        $display("[SUITE 1 RESULTS] Passed: %0d | Failed: %0d", current_suite_passed, current_suite_failed);

        // =====================================================================
        // TEST SUITE 2: Dynamic Range Clamping Bounds
        // =====================================================================
        $display("\n========================================================");
        $display("[RUNNING] Test Suite 2: Negative Underflow & Positive Overflow Stress");
        $display("========================================================");
        current_suite_passed = 0;
        current_suite_failed = 0;

        k11 = -8'sd5; k12 = -8'sd4; k13 = -8'sd3;
        k21 = -8'sd6; k22 = -8'sd7; k23 = -8'sd8;
        k31 = -8'sd2; k32 = -8'sd1; k33 = -8'sd4;

        for (r_init = 0; r_init < IMG_H; r_init = r_init + 1) begin
            for (c_init = 0; c_init < IMG_W; c_init = c_init + 1) begin
                current_frame[r_init][c_init] = 8'd240;
            end
        end

        send_frame;
        #(CLK_PERIOD * 35);
        $display("[SUITE 2 RESULTS] Negative Clamping Passed: %0d | Failed: %0d", current_suite_passed, current_suite_failed);

        // =====================================================================
        // TEST SUITE 3: Checkerboard Full-Swing Toggle
        // =====================================================================
        $display("\n========================================================");
        $display("[RUNNING] Test Suite 3: Checkerboard Full-Swing Switching (0 <-> 255)");
        $display("========================================================");
        current_suite_passed = 0;
        current_suite_failed = 0;

        k11 =  8'sd0; k12 = -8'sd1; k13 =  8'sd0;
        k21 = -8'sd1; k22 =  8'sd4; k23 = -8'sd1;
        k31 =  8'sd0; k32 = -8'sd1; k33 =  8'sd0;

        for (r_init = 0; r_init < IMG_H; r_init = r_init + 1) begin
            for (c_init = 0; c_init < IMG_W; c_init = c_init + 1) begin
                current_frame[r_init][c_init] = ((r_init + c_init) % 2 == 0) ? 8'd0 : 8'd255;
            end
        end

        send_frame;
        #(CLK_PERIOD * 35);
        $display("[SUITE 3 RESULTS] Checkerboard Passed: %0d | Failed: %0d", current_suite_passed, current_suite_failed);

        // =====================================================================
        // Final Regression Summary
        // =====================================================================
        $display("\n========================================================");
        $display("[OVERALL REGRESSION SUMMARY]");
        $display("  Total Operations Checked : %0d", (total_tests_passed + total_tests_failed));
        $display("  Total Passed             : %0d", total_tests_passed);
        $display("  Total Failed             : %0d", total_tests_failed);
        if (total_tests_failed == 0 && total_tests_passed > 0) begin
            $display(">>> VERIFICATION STATUS: 100%% PASSED (Zero Discrepancies) <<<");
        end else begin
            $display(">>> VERIFICATION STATUS: FAILED (Review Error Diagnoses Above) <<<");
        end
        $display("========================================================\n");

        $finish;
    end

    // Scoreboard Checker
    integer out_r = 1;
    integer out_c = 1;
    reg [7:0] exp_pixel;
    integer raw_math_golden; // integer is inherently 32-bit signed in Verilog

    always @(negedge clk) begin
        if (rst_n && out_valid) begin
            exp_pixel = compute_golden(out_r, out_c);

            raw_math_golden = ($signed({1'b0, current_frame[out_r-1][out_c-1]}) * k11) +
                              ($signed({1'b0, current_frame[out_r-1][out_c  ]}) * k12) +
                              ($signed({1'b0, current_frame[out_r-1][out_c+1]}) * k13) +
                              ($signed({1'b0, current_frame[out_r  ][out_c-1]}) * k21) +
                              ($signed({1'b0, current_frame[out_r  ][out_c  ]}) * k22) +
                              ($signed({1'b0, current_frame[out_r  ][out_c+1]}) * k23) +
                              ($signed({1'b0, current_frame[out_r+1][out_c-1]}) * k31) +
                              ($signed({1'b0, current_frame[out_r+1][out_c  ]}) * k32) +
                              ($signed({1'b0, current_frame[out_r+1][out_c+1]}) * k33);

            if (out_pixel !== exp_pixel) begin
                total_tests_failed   = total_tests_failed + 1;
                current_suite_failed = current_suite_failed + 1;
                $display("[ERROR MISMATCH] Time: %0t ps | (R:%0d, C:%0d) -> DUT=%3d | Exp=%3d | RawSum=%5d",
                         $time, out_r, out_c, out_pixel, exp_pixel, raw_math_golden);
            end else begin
                total_tests_passed   = total_tests_passed + 1;
                current_suite_passed = current_suite_passed + 1;
                $display("  [MATCH] (R:%0d, C:%0d) -> DUT=%3d | Golden=%3d | RawSum=%5d",
                         out_r, out_c, out_pixel, exp_pixel, raw_math_golden);
            end

            if (out_c == IMG_W - 2) begin
                out_c <= 1;
                if (out_r == IMG_H - 2)
                    out_r <= 1;
                else
                    out_r <= out_r + 1;
            end else begin
                out_c <= out_c + 1;
            end
        end
    end

endmodule