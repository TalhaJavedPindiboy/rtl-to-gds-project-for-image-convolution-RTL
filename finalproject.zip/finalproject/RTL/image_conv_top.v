`timescale 1ns / 1ps

module line_buffer #(
    parameter DATA_WIDTH  = 8,
    parameter LINE_LENGTH = 8
)(
    input  wire                  clk,
    input  wire                  rst_n,
    input  wire                  wr_en,
    input  wire [DATA_WIDTH-1:0] din,
    output wire [DATA_WIDTH-1:0] dout
);
    reg [DATA_WIDTH-1:0] mem [0:LINE_LENGTH-1];
    reg [15:0] wr_ptr;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            wr_ptr <= 16'd0;
        end else if (wr_en) begin
            if (wr_ptr == LINE_LENGTH - 1)
                wr_ptr <= 16'd0;
            else
                wr_ptr <= wr_ptr + 1'b1;
        end
    end

    always @(posedge clk) begin
        if (wr_en) begin
            mem[wr_ptr] <= din;
        end
    end

    assign dout = mem[wr_ptr];
endmodule

module sliding_window_3x3 #(
    parameter DATA_WIDTH = 8,
    parameter IMG_WIDTH  = 8,
    parameter IMG_HEIGHT = 8
)(
    input  wire                  clk,
    input  wire                  rst_n,
    input  wire                  in_valid,
    input  wire [DATA_WIDTH-1:0] in_pixel,
    output reg                   window_valid,
    output reg  [DATA_WIDTH-1:0] p11, p12, p13,
    output reg  [DATA_WIDTH-1:0] p21, p22, p23,
    output reg  [DATA_WIDTH-1:0] p31, p32, p33
);
    wire [DATA_WIDTH-1:0] lb0_dout;
    wire [DATA_WIDTH-1:0] lb1_dout;

    line_buffer #(.DATA_WIDTH(DATA_WIDTH), .LINE_LENGTH(IMG_WIDTH)) u_lb0 (
        .clk(clk), .rst_n(rst_n), .wr_en(in_valid), .din(lb1_dout), .dout(lb0_dout)
    );

    line_buffer #(.DATA_WIDTH(DATA_WIDTH), .LINE_LENGTH(IMG_WIDTH)) u_lb1 (
        .clk(clk), .rst_n(rst_n), .wr_en(in_valid), .din(in_pixel), .dout(lb1_dout)
    );

    reg [15:0] col_cnt;
    reg [15:0] row_cnt;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            col_cnt <= 16'd0;
            row_cnt <= 16'd0;
        end else if (in_valid) begin
            if (col_cnt == IMG_WIDTH - 1) begin
                col_cnt <= 16'd0;
                if (row_cnt == IMG_HEIGHT - 1)
                    row_cnt <= 16'd0;
                else
                    row_cnt <= row_cnt + 1'b1;
            end else begin
                col_cnt <= col_cnt + 1'b1;
            end
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            p11 <= 8'd0; p12 <= 8'd0; p13 <= 8'd0;
            p21 <= 8'd0; p22 <= 8'd0; p23 <= 8'd0;
            p31 <= 8'd0; p32 <= 8'd0; p33 <= 8'd0;
            window_valid <= 1'b0;
        end else if (in_valid) begin
            p13 <= lb0_dout; p12 <= p13; p11 <= p12;
            p23 <= lb1_dout; p22 <= p23; p21 <= p22;
            p33 <= in_pixel; p32 <= p33; p31 <= p32;

            if ((row_cnt >= 2) && (col_cnt >= 2))
                window_valid <= 1'b1;
            else
                window_valid <= 1'b0;
        end else begin
            window_valid <= 1'b0;
        end
    end
endmodule

module conv_engine_3x3 #(
    parameter DATA_WIDTH  = 8,
    parameter COEFF_WIDTH = 8,
    parameter SHIFT_BITS  = 0
)(
    input  wire                          clk,
    input  wire                          rst_n,
    input  wire                          window_valid,
    input  wire [DATA_WIDTH-1:0]         p11, p12, p13,
    input  wire [DATA_WIDTH-1:0]         p21, p22, p23,
    input  wire [DATA_WIDTH-1:0]         p31, p32, p33,
    input  wire signed [COEFF_WIDTH-1:0] k11, k12, k13,
    input  wire signed [COEFF_WIDTH-1:0] k21, k22, k23,
    input  wire signed [COEFF_WIDTH-1:0] k31, k32, k33,
    output reg                           out_valid,
    output reg  [DATA_WIDTH-1:0]         out_pixel
);
    reg signed [16:0] mult_r [0:8];
    reg               v_pipe1;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            v_pipe1 <= 1'b0;
            mult_r[0] <= 17'sd0; mult_r[1] <= 17'sd0; mult_r[2] <= 17'sd0;
            mult_r[3] <= 17'sd0; mult_r[4] <= 17'sd0; mult_r[5] <= 17'sd0;
            mult_r[6] <= 17'sd0; mult_r[7] <= 17'sd0; mult_r[8] <= 17'sd0;
        end else begin
            v_pipe1   <= window_valid;
            mult_r[0] <= $signed({1'b0, p11}) * k11;
            mult_r[1] <= $signed({1'b0, p12}) * k12;
            mult_r[2] <= $signed({1'b0, p13}) * k13;
            mult_r[3] <= $signed({1'b0, p21}) * k21;
            mult_r[4] <= $signed({1'b0, p22}) * k22;
            mult_r[5] <= $signed({1'b0, p23}) * k23;
            mult_r[6] <= $signed({1'b0, p31}) * k31;
            mult_r[7] <= $signed({1'b0, p32}) * k32;
            mult_r[8] <= $signed({1'b0, p33}) * k33;
        end
    end

    reg signed [18:0] sum_l1_0, sum_l1_1, sum_l1_2, sum_l1_3;
    reg signed [16:0] mult_r8_d1;
    reg               v_pipe2;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            v_pipe2    <= 1'b0;
            sum_l1_0   <= 19'sd0; sum_l1_1 <= 19'sd0;
            sum_l1_2   <= 19'sd0; sum_l1_3 <= 19'sd0;
            mult_r8_d1 <= 17'sd0;
        end else begin
            v_pipe2    <= v_pipe1;
            sum_l1_0   <= mult_r[0] + mult_r[1];
            sum_l1_1   <= mult_r[2] + mult_r[3];
            sum_l1_2   <= mult_r[4] + mult_r[5];
            sum_l1_3   <= mult_r[6] + mult_r[7];
            mult_r8_d1 <= mult_r[8];
        end
    end

    reg signed [20:0] total_sum;
    reg               v_pipe3;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            v_pipe3   <= 1'b0;
            total_sum <= 21'sd0;
        end else begin
            v_pipe3   <= v_pipe2;
            total_sum <= (sum_l1_0 + sum_l1_1) + (sum_l1_2 + sum_l1_3) + mult_r8_d1;
        end
    end

    reg signed [20:0] scaled_sum;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            out_valid <= 1'b0;
            out_pixel <= {DATA_WIDTH{1'b0}};
        end else begin
            out_valid <= v_pipe3;
            if (v_pipe3) begin
                scaled_sum = total_sum >>> SHIFT_BITS;
                if (scaled_sum < 0)
                    out_pixel <= 8'd0;
                else if (scaled_sum > 255)
                    out_pixel <= 8'd255;
                else
                    out_pixel <= scaled_sum[DATA_WIDTH-1:0];
            end else begin
                out_pixel <= 8'd0;
            end
        end
    end
endmodule

module image_conv_top #(
    parameter DATA_WIDTH  = 8,
    parameter COEFF_WIDTH = 8,
    parameter IMG_WIDTH   = 8,
    parameter IMG_HEIGHT  = 8,
    parameter SHIFT_BITS  = 0
)(
    input  wire                          clk,
    input  wire                          rst_n,
    input  wire                          in_valid,
    input  wire [DATA_WIDTH-1:0]         in_pixel,
    input  wire signed [COEFF_WIDTH-1:0] k11, k12, k13,
    input  wire signed [COEFF_WIDTH-1:0] k21, k22, k23,
    input  wire signed [COEFF_WIDTH-1:0] k31, k32, k33,
    output wire                          out_valid,
    output wire [DATA_WIDTH-1:0]         out_pixel
);
    reg                          r_in_valid;
    reg [DATA_WIDTH-1:0]         r_in_pixel;
    reg signed [COEFF_WIDTH-1:0] r_k11, r_k12, r_k13;
    reg signed [COEFF_WIDTH-1:0] r_k21, r_k22, r_k23;
    reg signed [COEFF_WIDTH-1:0] r_k31, r_k32, r_k33;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            r_in_valid <= 1'b0;
            r_in_pixel <= 8'd0;
            r_k11 <= 8'sd0; r_k12 <= 8'sd0; r_k13 <= 8'sd0;
            r_k21 <= 8'sd0; r_k22 <= 8'sd0; r_k23 <= 8'sd0;
            r_k31 <= 8'sd0; r_k32 <= 8'sd0; r_k33 <= 8'sd0;
        end else begin
            r_in_valid <= in_valid;
            r_in_pixel <= in_pixel;
            r_k11 <= k11; r_k12 <= k12; r_k13 <= k13;
            r_k21 <= k21; r_k22 <= k22; r_k23 <= k23;
            r_k31 <= k31; r_k32 <= k32; r_k33 <= k33;
        end
    end

    wire [DATA_WIDTH-1:0] w_p11, w_p12, w_p13;
    wire [DATA_WIDTH-1:0] w_p21, w_p22, w_p23;
    wire [DATA_WIDTH-1:0] w_p31, w_p32, w_p33;
    wire                  w_win_valid;

    sliding_window_3x3 #(.DATA_WIDTH(DATA_WIDTH), .IMG_WIDTH(IMG_WIDTH), .IMG_HEIGHT(IMG_HEIGHT)) u_window (
        .clk(clk), .rst_n(rst_n), .in_valid(r_in_valid), .in_pixel(r_in_pixel),
        .window_valid(w_win_valid),
        .p11(w_p11), .p12(w_p12), .p13(w_p13),
        .p21(w_p21), .p22(w_p22), .p23(w_p23),
        .p31(w_p31), .p32(w_p32), .p33(w_p33)
    );

    conv_engine_3x3 #(.DATA_WIDTH(DATA_WIDTH), .COEFF_WIDTH(COEFF_WIDTH), .SHIFT_BITS(SHIFT_BITS)) u_engine (
        .clk(clk), .rst_n(rst_n), .window_valid(w_win_valid),
        .p11(w_p11), .p12(w_p12), .p13(w_p13),
        .p21(w_p21), .p22(w_p22), .p23(w_p23),
        .p31(w_p31), .p32(w_p32), .p33(w_p33),
        .k11(r_k11), .k12(r_k12), .k13(r_k13),
        .k21(r_k21), .k22(r_k22), .k23(r_k23),
        .k31(r_k31), .k32(r_k32), .k33(r_k33),
        .out_valid(out_valid), .out_pixel(out_pixel)
    );
endmodule