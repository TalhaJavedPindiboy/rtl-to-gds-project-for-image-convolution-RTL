current_design image_conv_top

create_clock -name clk -period 10.0 -waveform {0.0 5.0} [get_ports clk]

set_clock_transition -rise 0.1 [get_clocks clk]
set_clock_transition -fall 0.1 [get_clocks clk]
set_clock_uncertainty 0.05 [get_clocks clk]

set_false_path -from [get_ports rst_n]

set_input_delay -max 2.0 -clock [get_clocks clk] [remove_from_collection [all_inputs] [get_ports {clk rst_n}]]
set_input_delay -min 0.2 -clock [get_clocks clk] [remove_from_collection [all_inputs] [get_ports {clk rst_n}]]

set_output_delay -max 2.0 -clock [get_clocks clk] [all_outputs]
set_output_delay -min 0.2 -clock [get_clocks clk] [all_outputs]

set_load 0.05 [all_outputs]
set_max_fanout 16 [current_design]
set_max_transition 0.5 [current_design]