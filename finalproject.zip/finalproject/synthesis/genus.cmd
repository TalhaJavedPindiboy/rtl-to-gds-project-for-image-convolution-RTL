# Cadence Genus(TM) Synthesis Solution, Version 20.12-s150_1, built Oct 14 2021 10:38:13

# Date: Mon Oct 12 04:13:52 2026
# Host: localhost.localdomain (x86_64 w/Linux 3.10.0-1160.71.1.el7.x86_64) (2cores*4cpus*2physical cpus*13th Gen Intel(R) Core(TM) i7-1355U 12288KB)
# OS:   CentOS Linux release 7.9.2009 (Core)

source run_genus.tcl
