add_search_path . ../Lib ../lib -library -both
read_library -liberty -both \
    /home/admin/finalproject/synthesis/../Lib/slow_vdd1v0_basicCells.lib

