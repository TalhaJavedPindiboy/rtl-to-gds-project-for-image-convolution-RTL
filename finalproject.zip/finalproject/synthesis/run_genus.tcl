set DESIGN image_conv_top
set GEN_EFF medium
set MAP_OPT_EFF high

set_db / .init_lib_search_path  {. ../Lib ../lib}
set_db / .init_hdl_search_path  {. ../RTL ../rtl}
set_db / .library               {../Lib/slow_vdd1v0_basicCells.lib}
set_db / .information_level 7

# 1. Read & Elaborate
read_hdl "image_conv_top.v"
elaborate $DESIGN
check_design -unresolved

# 2. Read Constraints
read_sdc ../constraints/sdc.sdc

file mkdir outputs
file mkdir reports

# 3. Generic & Gate-level Synthesis
set_db / .syn_generic_effort $GEN_EFF
syn_generic

set_db / .syn_map_effort $MAP_OPT_EFF
syn_map

set_db / .syn_opt_effort $MAP_OPT_EFF
syn_opt

# 4. Generate Reports
report_timing > reports/${DESIGN}_timing.rpt
report_area   > reports/${DESIGN}_area.rpt
report_power  > reports/${DESIGN}_power.rpt
report_qor    > reports/${DESIGN}_qor.rpt

# 5. Export Gate Netlist
write_hdl -mapped > outputs/${DESIGN}_netlist.v
write_sdc > outputs/${DESIGN}_synth.sdc

puts "=========================================================="
puts " Genus Synthesis Complete: outputs/${DESIGN}_netlist.v     "
puts "=========================================================="
exit