if {![namespace exists ::IMEX]} { namespace eval ::IMEX {} }
set ::IMEX::dataVar [file dirname [file normalize [info script]]]
set ::IMEX::libVar ${::IMEX::dataVar}/libs

create_library_set -name slow_libset\
   -timing\
    [list ${::IMEX::libVar}/mmmc/slow_vdd1v0_basicCells.lib]
create_rc_corner -name typical_rc\
   -cap_table ${::IMEX::libVar}/mmmc/cln28hpl_1p10m+alrdl_5x2yu2yz_typical.capTbl\
   -preRoute_res 1\
   -postRoute_res 1\
   -preRoute_cap 1\
   -postRoute_cap 1\
   -postRoute_xcap 1\
   -preRoute_clkres 0\
   -preRoute_clkcap 0\
   -qx_tech_file ${::IMEX::libVar}/mmmc/typical_rc/gpdk045.tch
create_delay_corner -name slow_delay_corner\
   -library_set slow_libset\
   -rc_corner typical_rc
create_constraint_mode -name func_mode\
   -sdc_files\
    [list ${::IMEX::dataVar}/mmmc/modes/func_mode/func_mode.sdc]
create_analysis_view -name setup_view -constraint_mode func_mode -delay_corner slow_delay_corner -latency_file ${::IMEX::dataVar}/mmmc/views/setup_view/latency.sdc
create_analysis_view -name hold_view -constraint_mode func_mode -delay_corner slow_delay_corner -latency_file ${::IMEX::dataVar}/mmmc/views/hold_view/latency.sdc
set_analysis_view -setup [list setup_view] -hold [list hold_view]
