#######################################################
#                                                     
#  Innovus Command Logging File                     
#  Created on Tue Oct 13 02:29:09 2026                
#                                                     
#######################################################

#@(#)CDS: Innovus v20.17-s101_1 (64bit) 03/08/2022 14:46 (Linux 2.6.32-431.11.2.el6.x86_64)
#@(#)CDS: NanoRoute 20.17-s101_1 NR220302-0957/20_17-UB (database version 18.20.572) {superthreading v2.18}
#@(#)CDS: AAE 20.17-s015 (64bit) 03/08/2022 (Linux 2.6.32-431.11.2.el6.x86_64)
#@(#)CDS: CTE 20.17-s019_1 () Mar  7 2022 09:21:37 ( )
#@(#)CDS: SYNTECH 20.17-s007_1 () Mar  1 2022 07:15:24 ( )
#@(#)CDS: CPE v20.17-s054
#@(#)CDS: IQuantus/TQuantus 20.1.1-s463 (64bit) Thu Nov 4 21:32:22 PDT 2021 (Linux 2.6.32-431.11.2.el6.x86_64)

setLayerPreference rve_0 -color green -isVisible 1 -isSelectable 1 -lineWidth 5 -stipple none
setLayerPreference rve_1 -color darkblue -isVisible 1 -isSelectable 1 -lineWidth 5 -stipple none
setLayerPreference rve_2 -color slateblue -isVisible 1 -isSelectable 1 -lineWidth 5 -stipple none
setLayerPreference rve_3 -color turquoise -isVisible 1 -isSelectable 1 -lineWidth 5 -stipple none
setLayerPreference rve_4 -color lightgray -isVisible 1 -isSelectable 1 -lineWidth 5 -stipple none
setLayerPreference rve_5 -color wheat -isVisible 1 -isSelectable 1 -lineWidth 5 -stipple none
setLayerPreference rve_6 -color goldenrod -isVisible 1 -isSelectable 1 -lineWidth 5 -stipple none
setLayerPreference rve_7 -color yellow -isVisible 1 -isSelectable 1 -lineWidth 5 -stipple none
setLayerPreference rve_8 -color sandybrown -isVisible 1 -isSelectable 1 -lineWidth 5 -stipple none
setLayerPreference rve_9 -color coral -isVisible 1 -isSelectable 1 -lineWidth 5 -stipple none
setLayerPreference rve_10 -color red -isVisible 1 -isSelectable 1 -lineWidth 5 -stipple none
setLayerPreference rve_11 -color tomato -isVisible 1 -isSelectable 1 -lineWidth 5 -stipple none
setLayerPreference rve_12 -color firebrick -isVisible 1 -isSelectable 1 -lineWidth 5 -stipple none
setLayerPreference rve_13 -color purple -isVisible 1 -isSelectable 1 -lineWidth 5 -stipple none
setLayerPreference rve_14 -color violet -isVisible 1 -isSelectable 1 -lineWidth 5 -stipple none
setLayerPreference rve_15 -color tan -isVisible 1 -isSelectable 1 -lineWidth 5 -stipple none
set_global _enable_mmmc_by_default_flow      $CTE::mmmc_default
suppressMessage ENCEXT-2799
getVersion
win
setMultiCpuUsage -localCpu 4
set init_verilog ../synthesis/outputs/image_conv_top_netlist.v
set init_top_cell image_conv_top
set init_lef_file {../Lib/lef/gsclib045_tech.lef ../Lib/lef/gsclib045_macro.lef}
set init_pwr_net VDD
set init_gnd_net VSS
set init_mmmc_file image_conv_top.view
set init_io_file image_conv_top.io
init_design
freeDesign
init_design
setMultiCpuUsage -localCpu 4
set init_verilog ../synthesis/outputs/image_conv_top_netlist.v
set init_top_cell image_conv_top
set init_lef_file {../Lib/lef/gsclib045_tech.lef ../Lib/lef/gsclib045_macro.lef}
set init_pwr_net VDD
set init_gnd_net VSS
set init_mmmc_file image_conv_top.view
set init_io_file image_conv_top.io
init_design
setDrawView place
setDrawView fplan
getIoFlowFlag
setIoFlowFlag 0
floorPlan -coreMarginsBy die -site CoreSite -r 1 0.7 10 10 10 10
uiSetTool select
getIoFlowFlag
fit
editPin -edge Top -pin {clk rst_n in_valid in_pixel*} -spreadType side -spacing 2.0
editPin -edge Left -pin {k11* k12* k13*} -spreadType side -spacing 1.5
editPin -edge Bottom -pin {k21* k22* k23*} -spreadType side -spacing 1.5
editPin -edge Right -pin {out_valid out_pixel* k31* k32* k33*} -spreadType side -spacing 1.5
editPin -side Top -pin {clk rst_n in_valid in_pixel[0] in_pixel[1] in_pixel[2] in_pixel[3] in_pixel[4] in_pixel[5] in_pixel[6] in_pixel[7]} -spreadType side -spacing 2.0
editPin -side Left -pin {k11* k12* k13*} -spreadType side -spacing 1.5
editPin -side Bottom -pin {k21* k22* k23*} -spreadType side -spacing 1.5
editPin -side Right -pin {out_valid out_pixel[0] out_pixel[1] out_pixel[2] out_pixel[3] out_pixel[4] out_pixel[5] out_pixel[6] out_pixel[7] k31* k32* k33*} -spreadType side -spacing 1.5
editPin -side Top -layer Metal3 -pin {clk rst_n in_valid in_pixel[0] in_pixel[1] in_pixel[2] in_pixel[3] in_pixel[4] in_pixel[5] in_pixel[6] in_pixel[7]} -spreadType side -spacing 2.0
editPin -side Left -layer Metal4 -pin {k11* k12* k13*} -spreadType side -spacing 1.5
editPin -side Bottom -layer Metal3 -pin {k21* k22* k23*} -spreadType side -spacing 1.5
editPin -side Right -layer Metal4 -pin {out_valid out_pixel[0] out_pixel[1] out_pixel[2] out_pixel[3] out_pixel[4] out_pixel[5] out_pixel[6] out_pixel[7] k31* k32* k33*} -spreadType side -spacing 1.5
fit
getIoFlowFlag
globalNetConnect VDD -type pgpin -pin VDD -inst * -module {}
globalNetConnect VSS -type pgpin -pin VSS -inst * -module {}
globalNetConnect VDD -type tiehi -inst * -module {}
globalNetConnect VSS -type tielo -inst * -module {}
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
setAddRingMode -ring_target default -extend_over_row 0 -ignore_rows 0 -avoid_short 0 -skip_crossing_trunks none -stacked_via_top_layer Metal11 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size 1 -orthogonal_only true -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  noshape }
addRing -nets {VDD VSS} -type core_rings -follow core -layer {top Metal10 bottom Metal10 left Metal9 right Metal9} -width {top 1.5 bottom 1.5 left 1.5 right 1.5} -spacing {top 0.8 bottom 0.8 left 0.8 right 0.8} -offset {top 1.8 bottom 1.8 left 1.8 right 1.8} -center 0 -threshold 0 -jog_distance 0 -snap_wire_center_to_grid None
deleteAllPowerPreroutes
addRing -type core_rings -nets {VDD VSS} -width 1.5 -spacing 1.3 -offset 1.2 -layer {top Metal10 bottom Metal10 left Metal9 right Metal9}
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
set sprCreateIeRingOffset 1.0
set sprCreateIeRingThreshold 1.0
set sprCreateIeRingJogDistance 1.0
set sprCreateIeRingLayers {}
set sprCreateIeStripeWidth 10.0
set sprCreateIeStripeThreshold 1.0
setAddStripeMode -ignore_block_check false -break_at none -route_over_rows_only false -rows_without_stripes_only false -extend_to_closest_target none -stop_at_last_wire_for_area false -partial_set_thru_domain false -ignore_nondefault_domains false -trim_antenna_back_to_shape none -spacing_type edge_to_edge -spacing_from_block 0 -stripe_min_length stripe_width -stacked_via_top_layer Metal11 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size false -split_vias false -orthogonal_only true -allow_jog { padcore_ring  block_ring } -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  stripe    }
addStripe -nets {VDD VSS} -layer Metal10 -direction vertical -width 1.5 -spacing 1.3 -set_to_set_distance 35 -start_from left -start_offset 15 -switch_layer_over_obs false -max_same_layer_jog_length 2 -padcore_ring_top_layer_limit Metal11 -padcore_ring_bottom_layer_limit Metal1 -block_ring_top_layer_limit Metal11 -block_ring_bottom_layer_limit Metal1 -use_wire_group 0 -snap_wire_center_to_grid None
setAddStripeMode -ignore_block_check false -break_at none -route_over_rows_only false -rows_without_stripes_only false -extend_to_closest_target none -stop_at_last_wire_for_area false -partial_set_thru_domain false -ignore_nondefault_domains false -trim_antenna_back_to_shape none -spacing_type edge_to_edge -spacing_from_block 0 -stripe_min_length stripe_width -stacked_via_top_layer Metal11 -stacked_via_bottom_layer Metal1 -via_using_exact_crossover_size false -split_vias false -orthogonal_only true -allow_jog { padcore_ring  block_ring } -skip_via_on_pin {  standardcell } -skip_via_on_wire_shape {  stripe    }
addStripe -nets {VDD VSS} -layer Metal10 -direction vertical -width 1.5 -spacing 1.3 -set_to_set_distance 35 -start_from left -start_offset 15 -switch_layer_over_obs false -max_same_layer_jog_length 2 -padcore_ring_top_layer_limit Metal11 -padcore_ring_bottom_layer_limit Metal1 -block_ring_top_layer_limit Metal11 -block_ring_bottom_layer_limit Metal1 -use_wire_group 0 -snap_wire_center_to_grid None
setSrouteMode -viaConnectToShape { noshape }
sroute -connect { blockPin padPin padRing corePin floatingStripe } -layerChangeRange { Metal1(1) Metal11(11) } -blockPinTarget { nearestTarget } -padPinPortConnect { allPort oneGeom } -padPinTarget { nearestTarget } -corePinTarget { firstAfterRowEnd } -floatingStripeTarget { blockring padring ring stripe ringpin blockpin followpin } -allowJogging 1 -crossoverViaLayerRange { Metal1(1) Metal11(11) } -nets { VDD VSS } -allowLayerChange 1 -blockPin useLef -targetViaLayerRange { Metal1(1) Metal11(11) }
setPlaceMode -fp false
place_design
setDrawView place
setOptMode -fixCap true -fixTran true -fixFanoutLoad true
optDesign -preCTS
set_ccopt_property buffer_cells {BUFX2 BUFX4 BUFX8 BUFX12 CLKBUFX2 CLKBUFX4 CLKBUFX8 CLKBUFX12}
set_ccopt_property inverter_cells {INVX1 INVX2 INVX4 INVX8 CLKINVX1 CLKINVX2 CLKINVX4 CLKINVX8}
create_ccopt_clock_tree_spec
ccopt_design
ctd_win -side none -id ctd_window
setNanoRouteMode -quiet -timingEngine {}
setNanoRouteMode -quiet -routeWithTimingDriven 1
setNanoRouteMode -quiet -routeWithSiDriven 1
setNanoRouteMode -quiet -routeTopRoutingLayer 11
setNanoRouteMode -quiet -routeBottomRoutingLayer 1
setNanoRouteMode -quiet -drouteEndIteration {}
setNanoRouteMode -drouteEndIteration default
setNanoRouteMode -routeWithTimingDriven true -routeWithSiDriven true -drouteFixAntenna true
routeDesign
setAnalysisMode -analysisType onChipVariation -cppr both
optDesign -postRoute -setup -hold
addFiller -cell {FILL64 FILL32 FILL16 FILL8 FILL4 FILL2 FILL1} -prefix FILLER
fit
getFillerMode -quiet
addFiller -cell FILL1 FILL16 FILL2 FILL32 FILL4 FILL64 FILL8 -prefix FILLER
fit
verifyConnectivity -type all -error 1000 -warning 50
getMultiCpuUsage -localCpu
get_verify_drc_mode -disable_rules -quiet
get_verify_drc_mode -quiet -area
get_verify_drc_mode -quiet -layer_range
get_verify_drc_mode -check_ndr_spacing -quiet
get_verify_drc_mode -check_only -quiet
get_verify_drc_mode -check_same_via_cell -quiet
get_verify_drc_mode -exclude_pg_net -quiet
get_verify_drc_mode -ignore_trial_route -quiet
get_verify_drc_mode -max_wrong_way_halo -quiet
get_verify_drc_mode -use_min_spacing_on_block_obs -quiet
get_verify_drc_mode -limit -quiet
set_verify_drc_mode -disable_rules {} -check_ndr_spacing auto -check_only default -check_same_via_cell false -exclude_pg_net false -ignore_trial_route false -ignore_cell_blockage false -use_min_spacing_on_block_obs auto -report image_conv_top.drc.rpt -limit 1000
verify_drc
set_verify_drc_mode -area {0 0 0 0}
verifyConnectivity -type all -error 1000 -warning 50
saveDesign outputs/image_conv_top_final.enc
saveNetlist outputs/image_conv_top_final.v -includePhysicalCell FILLER*
saveNetlist outputs/image_conv_top_final_sim.v
saveNetlist outputs/image_conv_top_final.v -phys
setExtractRCMode -engine postRoute -effortLevel signoff
extractRC
setExtractRCMode -engine postRoute -effortLevel low
extractRC
rcOut -spef outputs/image_conv_top.spef
streamOut outputs/image_conv_top.gds -mapFile streamOut.map -merge ../Lib/lef/gsclib045_macro.lef -stripes 1 -units 1000 -mode ALL
streamOut outputs/image_conv_top.gds -mapFile streamOut.map -libName DesignLib -units 2000 -mode ALL
report_area > reports/image_conv_top_area.rpt
reportDensityMap > reports/image_conv_top_density.rpt
report_timing -late -max_paths 50 -view setup_view > reports/image_conv_top_setup_timing.rpt
report_timing -early -max_paths 50 -view hold_view > reports/image_conv_top_hold_timing.rpt
report_analysis_coverage > reports/image_conv_top_timing_coverage.rpt
set_power_analysis_mode -analysis_view setup_view
report_power -outfile reports/image_conv_top_power.rpt
saveDesign outputs/image_conv_top_final.enc -rc
saveDesign outputs/image_conv_top_final.enc -rc
